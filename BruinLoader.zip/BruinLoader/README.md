# BruinLoader
An app to load into the Bruin Life system. Uses Swift and CloudKit.
