//
//  StartTableViewController.swift
//  BruinLoader
//
//  Created by Matthew DeCoste on 2/6/15.
//  Copyright (c) 2015 Matthew DeCoste. All rights reserved.
//

import UIKit

var backgroundQueue = dispatch_queue_create("Bruin Loader Mac Background", nil)

struct LoadDetails {
	let numDays: Int
	let loadQuick: Bool
}

class StartTableViewController: UITableViewController {
	var cells: Array<(name: String, value: Bool)> = [("Update Hall Menus", true), ("How Many Days Ahead?", false), ("Update Quick", false)]
	var hallRow: Int = 0
	var quickRow: Int = 1
	let cellID = "Cell"
	var loadDetails: LoadDetails!
	
	var numLoading = 8 {
		didSet {
			tableView.cellForRowAtIndexPath(NSIndexPath(forRow: 1, inSection: 0))?.textLabel?.text = "Days in Advance: \(numLoading)"
		}
	}
	
	var loadDiningPath: NSIndexPath = NSIndexPath(forRow: 0, inSection: 0)
	var numDaysPath: NSIndexPath = NSIndexPath(forRow: 1, inSection: 0)
	var loadQuickPath: NSIndexPath = NSIndexPath(forRow: 2, inSection: 0)
	
    override func viewDidLoad() {
        super.viewDidLoad()
		
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: cellID)
		
		navigationItem.title = "Start"
		navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Go!", style: .Plain, target: self, action: "load")
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
		return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return cells.count
    }

	override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
		return optionsCell(indexPath.row)
	}
	
	func optionsCell(row: Int) -> UITableViewCell {
		let cell = tableView.dequeueReusableCellWithIdentifier(cellID, forIndexPath: NSIndexPath(forRow: row, inSection: 0)) as UITableViewCell
		let info = cells[row]
		
		cell.textLabel?.text = info.name
		
		if row == 1 {
			cell.textLabel?.text = "Days in Advance: \(numLoading)"
			
			let stepper = UIStepper()
			stepper.value = Double(numLoading)
			stepper.maximumValue = 30
			stepper.addTarget(self, action: "dayChange:", forControlEvents: .ValueChanged)
			cell.accessoryView = stepper
			cell.accessoryType = .None
			cell.selectionStyle = .None
		} else {
			cell.accessoryView = nil
			cell.accessoryType = info.value ? .Checkmark : .None
			cell.selectionStyle = .Default
		}
		
		return cell
	}
	
	override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
		if indexPath.section == 0 {
			_changeCheck(indexPath, newValue: !cells[indexPath.row].value)
		}
		tableView.deselectRowAtIndexPath(indexPath, animated: true)
	}
	
	private func _changeCheck(path: NSIndexPath, newValue: Bool) {
		cells[path.row].value = newValue
		tableView.cellForRowAtIndexPath(path)?.accessoryType = cells[path.row].value ? .Checkmark : .None
	}
	
	func dayChange(sender: UIStepper) {
		numLoading = Int(sender.value)
	}
	
	// MARK: - Segues
	
	func load(numberDays: Int, quick: Bool) {
		numLoading = numberDays
		_changeCheck(loadDiningPath, newValue: (numberDays > 0))
		_changeCheck(loadQuickPath, newValue: quick)
		
		load(LoadDetails(numDays: numberDays, loadQuick: quick))
	}
	
	func load() {
		load(LoadDetails(numDays: cells[0].value ? numLoading : 0, loadQuick: cells[2].value))
	}
	
	func load(details: LoadDetails) {
		loadDetails = details
		performSegueWithIdentifier("showDetail", sender: self)
	}
	
	override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
		if segue.identifier == "showDetail" {
			((segue.destinationViewController as? UINavigationController)?.topViewController as? ProgressTableViewController)?.load(loadDetails)
		}
	}
}
