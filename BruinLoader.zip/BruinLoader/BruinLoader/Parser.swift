//
//  Parser.swift
//  BruinLoader
//
//  Created by Matthew DeCoste on 3/26/15.
//  Copyright (c) 2015 Matthew DeCoste. All rights reserved.
//

import UIKit


func preload(daysAhead: Int = 7) {
	if daysAhead >= 0 {
		preload(Array(0...daysAhead))
	}
}

func preload(days: Array<Int>) {
	let cal = NSCalendar.currentCalendar()
	for day in days.map({ return cal.dateByAddingUnit(.Day, value: $0, toDate: cal.startOfDayForDate(NSDate()), options: [])! }) {
		loadAllBrief(day)
	}
}

func uploadDay(brief: DayBrief) {
	let date = brief.date
	let data = serialize(brief)
	CloudManager.sharedInstance.addRecord(date, data: data, completion: { _ in updateProgress(date, progress: .Uploaded, data: data) }, halted: { updateProgress(date, progress: .NoChange, data: data) })
}

func updateProgress(date: NSDate, progress: Progress, data: NSData) {
	postProgressNotification(date, progress: progress)
	postProgressNotification(date, data: data)
}

func loadAllBrief(date: NSDate) {
	postProgressNotification(date, progress: .Loading)
	
	let hours = loadHours(date), day = DayBrief(date: date, meals: [:])
	for meal in MealType.allMeals(date, includeLateNight: true) {
		postProgressNotification(date, meal: meal)
		if let mealHours = hours[meal] {
			let mealBrief = MealBrief(halls: [:])
			
			let hasURLtoLoad = meal.urlCode() != nil // basically if it's not late night
			
			if hasURLtoLoad {
				for hall in Halls.allDiningHalls {
					postProgressNotification(date, hall: hall)
					let (isOpen, hallBrief, foods) = loadMealBrief(hall, meal: meal, date: date)
					let hasData = isOpen && hallBrief.sections.count > 0
					if hasData {
						if let hallHours = mealHours[hall] where hallHours.open {
							hallBrief.openTime = unwrappedTime(hallHours.openTime)
							hallBrief.closeTime = unwrappedTime(hallHours.closeTime)
						}
						
						mealBrief.halls[hall] = hallBrief
						for (recipe, food) in foods {
							if let dayRecipe = day.foods[recipe] {
								if let _ = dayRecipe.places[meal.rawValue] { // make a list of where it's from
									day.foods[recipe]?.places[meal.rawValue]?[hall.rawValue] = true
								} else {
									day.foods[recipe]?.places[meal.rawValue] = [hall.rawValue : true]
								}
							} else { // if first time, create food collection
								day.foods[recipe] = FoodCollection(info: food)
							}
						}
					}
				}
			}
			
			// attach the quick service (QS) hours (it isn't in the load-once-use-forever QS menus)
			for quick in Halls.allQuickServices {
				postProgressNotification(date, hall: quick)
				let isDeNeveNotLateNight = quick == .DeNeve && meal != .LateNight
				if let quickHours = mealHours[quick] where quickHours.open && !isDeNeveNotLateNight {
					// add empty listing in mealInfo for the hall (but real open / close times)
					let hallBrief = RestaurantBrief(hall: quick, openTime: quickHours.openTime, closeTime: quickHours.closeTime)
					mealBrief.halls[quick] = hallBrief
				}
			}
			day.meals[meal] = mealBrief
		}
	}
	
	postProgressNotification(date, progress: .Loaded)
	uploadDay(day)
}

// MARK: Quick Service Parsers

func loadAndSaveQuick() {
	let quickData = serialize(loadQuick())
	CloudManager.sharedInstance.addQuickRecord(quickData, completion: { (record) -> Void in
		postProgressNotification(nil, progress: .Uploaded)
	})
}

func loadQuick() -> DayBrief {
	postProgressNotification(nil, progress: .Loading)
	
	// Bruin Cafe
	postProgressNotification(nil, hall: .BruinCafe)
	let bcBrief = loadBruinCafe()
	
	// 1919
	postProgressNotification(nil, hall: .Cafe1919)
	let c1919Brief = loadCafe1919()
	
	// Rendezvous
	postProgressNotification(nil, hall: .Rendezvous)
	let rBrief = loadRendezvous()
	
	// Late Night
	postProgressNotification(nil, hall: .DeNeve)
	let lnBrief = loadLateNight()
	
	// merge them all together into one day
	let allInfo: Array<DayBrief> = [bcBrief, c1919Brief, rBrief, lnBrief]
	
	let quickBrief = DayBrief()
	for meal in [.Breakfast, .Lunch, .Dinner, .LateNight] as Array<MealType> {
		let mealBrief = MealBrief(halls: [:])
		for info in allInfo {
			if let halls = info.meals[meal]?.halls {
				for hall in halls.keys {
					mealBrief.halls[hall] = halls[hall]
				}
			}
		}
		quickBrief.meals[meal] = mealBrief
	}
	
	for partBrief in allInfo {
		for (recipe, collection) in partBrief.foods {
			if quickBrief.foods[recipe] == nil {
				quickBrief.foods[recipe] = collection
			} else {
				for (meal, halls) in collection.places {
					for (hall, involved) in halls {
						quickBrief.foods[recipe]?.places[meal]?[hall] = involved
					}
				}
			}
		}
	}
	
	for (meal, mBrief) in quickBrief.meals {
		for (hall, _) in mBrief.halls {
			quickBrief.meals[meal]?.halls[hall]?.openTime = Time()
			quickBrief.meals[meal]?.halls[hall]?.closeTime = Time()
			// this guarantees that it won't be shown as open unless it is actually open that day
		}
	}
	
	postProgressNotification(nil, progress: .Loaded)
	return quickBrief
}

func loadBruinCafe() -> DayBrief {
	let currHall = Halls.BruinCafe
	var foods: Dictionary<String, FoodCollection> = [:]
	
	let bruinHTML: String
	do {
		bruinHTML = try NSString(contentsOfURL: NSURL(string: "http://menu.ha.ucla.edu/foodpro/bruincafe.asp")!, encoding: NSISOLatin1StringEncoding) as String
	} catch let bruinErr as NSError {
		bruinHTML = ""
		print(bruinErr)
	}
	
	let bruinDescriptions = foodDescriptions(bruinHTML)
	let hpple = Hpple(HTMLData: bruinHTML)
	
	let menuParts = hpple.searchWithXPathQuery("//div[@id='menuwrapper']/div[@class='section']")!
	let restBrief = RestaurantBrief(hall: currHall)
	
	for menu in menuParts {
		let sectionID = menu.attributes["id"] as! String
		let foodSections = hpple.searchWithXPathQuery("//div[@id='\(sectionID)' and @class='section']//div[@class='subsection']")!
		
		for section in foodSections where section.children?[1].attributes["class"] as? String == "subsectiontop" {
			let sectionBrief = SectionBrief(name: section.children![1].children![0].text!)
			
			for var i = 3; i < section.children?.count; i += 2 {
				let child = section.children![i]
				
				if let childClass = (child.attributes["class"] as? String) {
					// TODO: B, L, D, and PM tell you which meals each applies to. Use it?
					let validChars = NSCharacterSet(charactersInString: "BLDP")
					if String(childClass[childClass.startIndex]).stringByTrimmingCharactersInSet(validChars) == "" {
						// it's a food, process it
						var valid = true
						
						var food: FoodInfo = FoodInfo(name: "", recipe: "", type: .Regular)
						var price: String? = nil
						var descr: String? = nil
						
						for foodChildren in child.children ?? [] {
							if let spanClass = foodChildren.attributes["class"] as? String {
								if spanClass.rangeOfString("name") != nil {
									if foodChildren.text != nil && foodChildren.text! == "Soup of the Day:" {
										valid = false
									} else {
										if let processedFood = processFoodPart(foodChildren, descriptions: bruinDescriptions) {
											food = processedFood
										} else {
											valid = false
										}
									}
								}
								if spanClass.rangeOfString("price") != nil {
									price = foodChildren.text?.stringByTrimmingCharactersInSet(.whitespaceCharacterSet())
								}
								if spanClass.rangeOfString("desc") != nil {
									descr = foodChildren.text
								}
							}
						}
						
						if valid {
							let displayDescr = descr ?? ""
							let displayPrice = price ?? ""
							food.description = displayDescr == "" ? displayPrice : "\(displayDescr) (\(displayPrice))"
							foods[food.recipe] = FoodCollection(info: food)
							sectionBrief.foods.append(FoodBrief(food: food))
						}
					}
				}
			}
			restBrief.sections.append(sectionBrief)
		}
	}
	
	let breakfastBrief = RestaurantBrief(hall: currHall)
	let lunchBrief = RestaurantBrief(hall: currHall)
	let dinnerBrief = RestaurantBrief(hall: currHall)
	let lateNightBrief = RestaurantBrief(hall: currHall)
	
	// let's move things around for different meals
	for (index, section) in restBrief.sections.enumerate() {
		switch index {
		case 0...1: // Breakfast Only
			breakfastBrief.sections.append(section)
		case 8: // it's chips!
			section.name = "Chips"
			fallthrough
		case 2...7:
			lunchBrief.sections.append(section)
			dinnerBrief.sections.append(section)
			lateNightBrief.sections.append(section)
		case 10...13:
			section.name = "On the Go: " + section.name
			lunchBrief.sections.append(section)
		case 14...16:
			section.name = "On the Go: " + section.name
			dinnerBrief.sections.append(section)
			lateNightBrief.sections.append(section)
		default:
			// no one gets it
			section.name = "sad trombones"
		}
	}
	
	let dayBrief = DayBrief()
	dayBrief.foods = foods
	
	let mealsForDay: Array<(meal: MealType, info: RestaurantBrief)> = [(.Breakfast, breakfastBrief), (.Lunch, lunchBrief), (.Dinner, dinnerBrief), (.LateNight, lateNightBrief)]
	for (meal, info) in mealsForDay {
		dayBrief.meals[meal] = MealBrief(halls: [currHall : info])
	}
	
	return dayBrief
}

func loadCafe1919() -> DayBrief {
	let currHall = Halls.Cafe1919
	var foods: Dictionary<String, FoodCollection> = [:]
	
	let url = NSURL(string: "http://menu.ha.ucla.edu/foodpro/cafe1919.asp")!
	let html: String
	do {
		html = try NSString(contentsOfURL: url, encoding: NSISOLatin1StringEncoding) as String
	} catch let error as NSError {
		html = ""
		print(error)
	}
	
	let descriptions = foodDescriptions(html)
	let hpple = Hpple(HTMLData: html)
	
	var menuSections = hpple.searchWithXPathQuery("//div[@id='menuwrapper']/div[@class='menucontainer']/div[@class='section']")!
	let restBrief = RestaurantBrief(hall: currHall)
	
	for (index, menu) in menuSections[1...7].enumerate() { // TODO: remove this hardcoding
		if index == 5 {
			continue // skip bibite entirely
		}
		
		let sectionID = menu.attributes["id"] as! String
		let classID = "section_menu" + (sectionID == "s7" ? "" : " hascombo")
		
		let sectionTitle = hpple.searchWithXPathQuery("//div[@id='\(sectionID)' and @class='section']//div[@class='section_banner']/img")![0].attributes["alt"] as! String
		let sectionBrief = SectionBrief(name: sectionTitle)
		
		let foodsQuery = sectionTitle != "Bibite" ? "//div[@id='\(sectionID)' and @class='section']//td[@class='\(classID)']/div" : "//td[@id='coffeetablecell_left']"
		let foodsRaw = hpple.searchWithXPathQuery(foodsQuery)!
		
		for foodRaw in foodsRaw {
			var valid = false
			
			var food: FoodInfo = FoodInfo(name: "", recipe: "", type: .Regular)
			var price: String = ""
			var subtitle: String = ""
			var descr: String = ""
			
			if let chilrenRaw = foodRaw.children {
				for aspect in chilrenRaw {
					if let spanClass = aspect.attributes["class"] as? String {
						if spanClass.rangeOfString("name") != nil {
							if let processedFood = processFoodPart(aspect, descriptions: descriptions) {
								food = processedFood
								valid = true
							}
						}
						if spanClass.rangeOfString("price") != nil {
							price = aspect.text!.stringByTrimmingCharactersInSet(.whitespaceCharacterSet())
						}
						if spanClass.rangeOfString("desc1") != nil {
							switch sectionTitle {
							case "Lasagna", "Bibite", "Dolci":
								descr = aspect.text!
							default:
								subtitle = aspect.text!
							}
						}
						if spanClass.rangeOfString("desc2") != nil {
							descr = aspect.text!
						}
					}
				}
			}
			
			if valid {
				let foodBrief = FoodBrief(food: food)
				
				food.description = descr == "" ? price : "\(descr) (\(price))"
				
				if subtitle != "" {
					foodBrief.sideBrief = FoodBrief(food: FoodInfo(name: subtitle, recipe: "", type: .Regular))
				}
				
				sectionBrief.foods.append(foodBrief)
				foods[food.recipe] = FoodCollection(info: food)
			}
		}
		restBrief.sections.append(sectionBrief)
	}
	
	let lunchBrief = RestaurantBrief(hall: currHall)
	let dinnerBrief = RestaurantBrief(hall: currHall)
	let lateNightBrief = RestaurantBrief(hall: currHall)
	
	for (index, section) in restBrief.sections.enumerate() {
		switch index {
		case 3: // no late night!
			lunchBrief.sections.append(section)
			dinnerBrief.sections.append(section)
		default:
			lunchBrief.sections.append(section)
			dinnerBrief.sections.append(section)
			lateNightBrief.sections.append(section)
		}
	}
	
	let dayBrief = DayBrief()
	dayBrief.date = NSDate()
	
	let mealsForDay: Array<(meal: MealType, info: RestaurantBrief)> = [(.Lunch, lunchBrief), (.Dinner, dinnerBrief), (.LateNight, lateNightBrief)]
	for (meal, brief) in mealsForDay {
		dayBrief.meals.updateValue(MealBrief(halls: [currHall : brief]), forKey: meal)
	}
	dayBrief.foods = foods
	
	return dayBrief
}

func loadRendezvous() -> DayBrief {
	let currHall = Halls.Rendezvous
	var foods: Dictionary<String, FoodCollection> = [:]
	
	let url = NSURL(string: "http://menu.ha.ucla.edu/foodpro/rendezvous.asp")!
	let html: String
	do {
		html = try NSString(contentsOfURL: url, encoding: NSISOLatin1StringEncoding) as String
	} catch let error as NSError {
		html = ""
		print(error.description)
	}
	
	let descriptions = foodDescriptions(html)
	let hpple = Hpple(HTMLData: html)
	
	var menuSections = hpple.searchWithXPathQuery("//div[@id='menuwrapper']/div[@class='menucontainer']/div[@class='section']")!
	let restBrief = RestaurantBrief(hall: currHall)
	
	for menuSection in menuSections[0...3] {
		let sectionID = menuSection.attributes["id"] as! String
		let sectionsQuery = "//div[@id='\(sectionID)' and @class='section']/div"
		let sectionsRaw = hpple.searchWithXPathQuery(sectionsQuery)!
		
		for sectionRaw in sectionsRaw {
			var sectionExists = false
			var currSectionName = ""
			var currSectionFoods: Array<FoodBrief> = []
			
			for line in sectionRaw.children ?? [] where line.raw != nil {
				switch line.tagName! {
				case "h1":
					if sectionExists {
						let nextSection = SectionBrief(name: currSectionName)
						for food in currSectionFoods {
							nextSection.foods.append(food)
						}
						restBrief.sections.append(nextSection)
						sectionExists = false
					}
					if line.text! != "" {
						currSectionName = line.text!
					}
					currSectionFoods = []
				case "div":
					let lineClass = line.attributes["class"] as! String
					if lineClass.rangeOfString("item") != nil {
						sectionExists = true
						
						var valid = false
						var food: FoodInfo = FoodInfo(name: "", recipe: "", type: .Regular)
						var price: String = ""
						var subtitle: String = ""
						
						for span in line.children ?? [] {
							if let spanClass = span.attributes["class"] as? String {
								if spanClass.rangeOfString("name") != nil {
									if span.raw?.rangeOfString("Coffee") != nil {
										var foodName = ""
										var recipe = ""
										let type: FoodType = span.raw?.rangeOfString("Boba") == nil ? .Vegan : .Vegetarian
										for coffeeChild in span.children ?? [] {
											if coffeeChild.tagName == "a" {
												foodName = coffeeChild.text ?? ""
												let recipeArea = coffeeChild.attributes["href"] as? String ?? ""
												var recipeRange = recipeArea.rangeOfString("=")!
												recipeRange.startIndex = recipeRange.startIndex.successor()
												recipeRange.endIndex = recipeArea.rangeOfString("&")!.startIndex
												recipe = recipeArea.substringWithRange(recipeRange)
											}
										}
										food = FoodInfo(name: foodName, recipe: recipe, type: type)
										
										valid = true
									} else if span.raw?.rangeOfString("Fountain Beverage") == nil {
										if let processedFood = processFoodPart(span, descriptions: descriptions) {
											food = processedFood
											valid = true
										}
									}
								}
								if spanClass.rangeOfString("price") != nil {
									price = span.text?.stringByTrimmingCharactersInSet(.whitespaceCharacterSet()) ?? ""
								}
								if spanClass.rangeOfString("desc") != nil {
									subtitle = span.text ?? ""
								}
							}
						}
						
						if valid {
							if let descr = descriptions[food.recipe] {
								food.description = descr
							}
							
							let foodBrief = FoodBrief(food: food)
							
							if subtitle != "" {
								food.description = subtitle
							}
							foodBrief.sideBrief = FoodBrief(food: FoodInfo(name: price, recipe: "", type: .Regular))
							
							foods[food.recipe] = FoodCollection(info: food)
							currSectionFoods.append(foodBrief)
						}
					}
				default:
					continue
				}
			}
			
			if sectionExists {
				let nextSection = SectionBrief(name: currSectionName)
				for food in currSectionFoods {
					nextSection.foods.append(food)
				}
				restBrief.sections.append(nextSection)
			}
		}
	}
	
	var theSections: Array<SectionBrief> = []
	
	let noodleBowlSection = SectionBrief(name: "Noodle Bowls")
	let asianSpecialsSection = SectionBrief(name: "Asian Daily Specials")
	
	let days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
	
	for (sectionIndex, section) in restBrief.sections.enumerate() {
		if sectionIndex == 8 {
			for (index, food) in section.foods.enumerate() {
				if let side = food.sideBrief {
					section.foods[index].sideBrief?.name = "\(days[(index)/2]) - \(side.name)"
				} else {
					section.foods[index].sideBrief = FoodBrief(food: FoodInfo(name: days[(index)/2], recipe: "", type: .Regular))
				}
			}
		}
		
		if section.name != "" || sectionIndex > 19 || sectionIndex < 10 {
			theSections.append(section)
		} else { // special cases for the noodle bowls and asian daily specials sections
			for (foodIndex, food) in section.foods.enumerate() {
				if let side = food.sideBrief {
					section.foods[foodIndex].sideBrief?.name = "\(days[(sectionIndex-10)/2]) - \(side.name)"
				} else {
					section.foods[foodIndex].sideBrief = FoodBrief(food: FoodInfo(name: days[(sectionIndex-10)/2], recipe: "", type: .Regular))
				}
				
				switch foodIndex % 2 {
				case 0:
					asianSpecialsSection.foods.append(food)
				default: // 1
					noodleBowlSection.foods.append(food)
				}
			}
		}
	}
	
	theSections.insert(noodleBowlSection, atIndex: 10)
	theSections.insert(asianSpecialsSection, atIndex: 11)
	
	for (index, boba) in theSections[16].foods.enumerate() {
		let prefix = index < 5 ? "16 oz. " : "32 oz. "
		theSections[16].foods[index].name = prefix + boba.name
	}
	
	let breakfastBrief = RestaurantBrief(hall: currHall)
	let lunchBrief = RestaurantBrief(hall: currHall)
	let dinnerBrief = RestaurantBrief(hall: currHall)
	let lateNightBrief = RestaurantBrief(hall: currHall)
	
	for (index, section) in theSections.enumerate() {
		switch index {
		case 0...5: // breakfast only!
			breakfastBrief.sections.append(section)
		case 6...16: // lunch to late night
			lunchBrief.sections.append(section)
			dinnerBrief.sections.append(section)
			lateNightBrief.sections.append(section)
		default: // desserts is late night only
			lateNightBrief.sections.append(section)
		}
	}
	
	
	let dayBrief = DayBrief()
	dayBrief.foods = foods
	dayBrief.date = NSDate()
	
	let mealsForDay: Array<(meal: MealType, info: RestaurantBrief)> = [(.Breakfast, breakfastBrief), (.Lunch, lunchBrief), (.Dinner, dinnerBrief), (.LateNight, lateNightBrief)]
	for (meal, info) in mealsForDay {
		dayBrief.meals[meal] = MealBrief(halls: [currHall : info])
	}
	
	return dayBrief
}

func loadLateNight() -> DayBrief {
	let currHall = Halls.DeNeve
	var foods: Dictionary<String, FoodCollection> = [:]
	
	let html: String
	do {
		html = try NSString(contentsOfURL: NSURL(string: "http://menu.ha.ucla.edu/foodpro/denevelatenight.asp")!, encoding: NSISOLatin1StringEncoding) as String
	} catch let error as NSError {
		html = ""
		print(error)
	}
	
	let descriptions = foodDescriptions(html)
	let hpple = Hpple(HTMLData: html)
	
	var menuSections = hpple.searchWithXPathQuery("//td[@id='borderinside']/div[@class='section']")!
	let restBrief = RestaurantBrief(hall: currHall)
	
	for (menuIndex, menuSection) in menuSections[0...2].enumerate() {
		let sectionID = menuSection.attributes["id"] as! String
		let sectionsQuery = "//div[@id='\(sectionID)' and @class='section']/div" + (menuIndex == 1 ? "/div" : "")
		let entriesRaw = hpple.searchWithXPathQuery(sectionsQuery)!
		
		var currSectionName = ""
		var currSectionFoods: Array<FoodBrief> = []
		for entryRaw in entriesRaw {
			let divType = entryRaw.attributes["class"] as! String
			if divType == "catheader" {
				let sectionName = entryRaw.children?[0].attributes["src"] as! String
				var underRange = sectionName.rangeOfString("_")!
				underRange.startIndex = underRange.endIndex
				underRange.endIndex = sectionName.rangeOfString(".png")!.startIndex
				var newName = sectionName.substringWithRange(underRange)
				
				let capStart = String(newName[newName.startIndex]).capitalizedString
				let firstRange = newName.startIndex...newName.startIndex
				newName.replaceRange(firstRange, with: capStart)
				if newName == "Mypizza" { newName = "MyPizza" }
				
				if currSectionFoods.count != 0 {
					let nextSection = SectionBrief(name: currSectionName)
					for food in currSectionFoods {
						nextSection.foods.append(food)
					}
					restBrief.sections.append(nextSection)
				}
				currSectionName = newName
				currSectionFoods = []
			} else if divType.rangeOfString("item") != nil {
				let entryHpple = Hpple(HTMLData: entryRaw.raw!)
				let foodParts = entryHpple.searchWithXPathQuery("//span")!
				
				var food: FoodInfo = FoodInfo(name: "", recipe: "", type: .Regular)
//				var price = ""
				var description = ""
				var subtitle = ""
				
				for foodPart in foodParts {
					let partClass = foodPart.attributes["class"] as! String
					if partClass.rangeOfString("name") != nil {
						if foodPart.raw?.rangeOfString("Fountain Beverage") == nil {
							if let processedFood = processFoodPart(foodPart, descriptions: descriptions) {
								food = processedFood
							}
						}
					} else if partClass.rangeOfString("price") != nil {
//						price = foodPart.text!
					} else if partClass.rangeOfString("desc") != nil {
						description = foodPart.text!
						
						if let swipeRange = description.rangeOfString(" Meal Plan Swipe") {
							var numberRange = swipeRange
							numberRange.endIndex = swipeRange.startIndex
							numberRange.startIndex = swipeRange.startIndex.predecessor()
							
							let number = description.substringWithRange(numberRange)
							let ending = number == "1" ? "" : "s"
							subtitle = number + " Swipe" + ending
						}
					}
				}
				
				if food.recipe != "" {
					foods[food.recipe] = FoodCollection(info: food)
				}
				
				if subtitle != "" {
					currSectionFoods.append(FoodBrief(food: food, sideFood: FoodInfo(name: subtitle, recipe: "", type: .Regular)))
				} else {
					currSectionFoods.append(FoodBrief(food: food))
				}
			}
		}
		if currSectionFoods.count != 0 {
			let nextSection = SectionBrief(name: currSectionName)
			for food in currSectionFoods {
				nextSection.foods.append(food)
			}
			restBrief.sections.append(nextSection)
		}
	}
	
	
	let dayBrief = DayBrief()
	dayBrief.date = NSDate()
	dayBrief.foods = foods
	
	dayBrief.meals = [.LateNight : MealBrief(halls: [.DeNeve : restBrief])]
	return dayBrief
}

// MARK: URL generators

// used to have a forceTwoDigits attribute, but it isn't needed
func dateURL(date: NSDate) -> String {
	let formatter = NSDateFormatter()
	formatter.dateFormat = "M"
	var dateString = formatter.stringFromDate(date) + "%2F"
	formatter.dateFormat = "d"
	dateString = dateString + formatter.stringFromDate(date) + "%2F"
	formatter.dateFormat = "yyyy"
	dateString = dateString + formatter.stringFromDate(date)
	
	return dateString
}

func hoursURL(date: NSDate) -> String {
	let dateString = dateURL(date)
	return "https://secure5.ha.ucla.edu/restauranthours/dining-hall-hours-by-day.cfm?serviceDate=\(dateString)"
}

func hallURL(hall: Halls, meal: MealType, date: NSDate) -> String {
	let dateString = dateURL(date)
	return "http://menu.ha.ucla.edu/foodpro/default.asp?location=\(hall.urlCode()!)&date=\(dateString)&meal=\(meal.urlCode()!)"
}

func foodURL(recipe: String, portion: String) -> String {
	return "http://menu.ha.ucla.edu/foodpro/recipedetail.asp?RecipeNumber=\(recipe)&PortionSize=\(portion)"
}

// MARK: HTML loaders
private func mealsForDay(date: NSDate) -> Array<MealType> {
	let dow = NSCalendar.currentCalendar().component(.Weekday, fromDate: date)
	return dow == 1 || dow == 7 ? [.Breakfast, .Brunch, .Dinner, .LateNight] : [.Breakfast, .Lunch, .Dinner, .LateNight]
}

func loadHours(date: NSDate) -> Dictionary<MealType, Dictionary<Halls, (open: Bool, openTime: Time?, closeTime: Time?)>> {
	var hours: Dictionary<MealType, Dictionary<Halls, (open: Bool, openTime: Time?, closeTime: Time?)>> = [:]
	let dayMeals = mealsForDay(date)
	for meal in dayMeals { hours[meal] = [:] }
	
	let htmlbase = hoursURL(date)
	
	// load the html value of the dining hours site
	let url = NSURL(string: htmlbase)!
	let html: String
	do {
		html = try NSString(contentsOfURL: url, encoding: NSISOLatin1StringEncoding) as String
	} catch let error as NSError {
		html = ""
		print(error.description)
	}
	
	// awful way to determine if the page has any useful data
	if let _ = html.rangeOfString("00am"), hourNodes = Hpple(HTMLData: html).searchWithXPathQuery("//table") {
		// awful way to limit the parsing code to sections I know will have legimiate data
		for node in Array(hourNodes[3...hourNodes.count-1]) {
			var subNodes = node.children ?? [], subNodeIndex = subNodes.count - 1
			
			// TODO: find a good way to filter
			//			subNodes.filter({ (element: HppleElement) -> Bool in
			//
			//			})
			
			// awful way to remove padding sections that have no data (take out the even entries, back to front to prevent certain issues)
			while subNodeIndex >= 0 {
				if subNodeIndex % 2 == 0 { subNodes.removeAtIndex(subNodeIndex) }
				subNodeIndex--
			}
			
			for body in Array(subNodes[2...subNodes.count-1]) {
				if var subBodies = body.children {
					// same awful filtering is implemented up here
					for var subBodyIndex = subBodies.count - 1; subBodyIndex >= 0; subBodyIndex-- {
						if subBodyIndex % 2 == 0 {
							subBodies.removeAtIndex(subBodyIndex)
						}
					}
					
					var hall: Halls? = nil
					for (layerIndex, layer) in subBodies.enumerate() {
						if layerIndex == 0 {
							if let restaurantName = layer.children?[1].text?.stringByReplacingOccurrencesOfString("\r\n\t", withString: "").stringByTrimmingCharactersInSet(.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString("Ã©", withString: "e"), newHall = Halls.hallForString(restaurantName) {
								hall = newHall
							} // otherwise leave as nil
						} else {
							let meal: MealType = dayMeals[layerIndex-1]
							var open = false, openTime: Time?, closeTime: Time?
							
							if let currHall = hall, openString = layer.children?[1].text?.stringByReplacingOccurrencesOfString("\r\n\t", withString: "").stringByTrimmingCharactersInSet(.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" -", withString: "") where openString.rangeOfString("CLOSED") == nil {
								open = true
								openTime = Time(hoursString: openString)
								
								if let closeString = layer.children?[3].text?.stringByReplacingOccurrencesOfString("\r\n\t", withString: "").stringByTrimmingCharactersInSet(.whitespaceCharacterSet()) {
									closeTime = Time(hoursString: closeString)
								}
								
								if let mealHours = hours[meal] {
									if let hallMealHours = mealHours[currHall] where hallMealHours.openTime != nil { }
									else { // equilvalent to hours[meal][currHall] == nil || hours[meal][currHall].openTime == nil
										hours[meal]?[currHall] = (open, openTime, closeTime)
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return hours
}

func loadMealBrief(hall: Halls, meal: MealType, date: NSDate) -> (open: Bool, info: RestaurantBrief, foods: Dictionary<String, FoodInfo>) {
	let restaurant = RestaurantBrief(hall: hall)
	
	// load html and verify it's valid.
	var html: String
	do {
		let url = NSURL(string: hallURL(hall, meal: meal, date: date))!
		html = try String(contentsOfURL: url, encoding: NSISOLatin1StringEncoding)
		if html.rangeOfString("menulocheader") == nil {
			return (false, restaurant, [:])
		}
	} catch let error as NSError {
		print(error)
		return (false, restaurant, [:])
	}
	
	var foods: Dictionary<String, FoodInfo> = [:]
	var mealDescriptions = foodDescriptions(html)
	var foodNodes = Hpple(HTMLData: html).searchWithXPathQuery("//body/div/div[position()=3]/div/table/node()")! // assuming so much about the structure of the page...
	var sections: Array<Array<HppleElement>> = []
	let foodNodeCycle = Array(foodNodes[7..<foodNodes.count]).filter { (element: HppleElement) -> Bool in return !element.isTextNode }
	for element in foodNodeCycle {
		if let middleChildren = element.children?[1].children?[1].children {
			sections.append(middleChildren.filter({ (element: HppleElement) -> Bool in return !element.isTextNode }))
		}
	}
	
	for entry in sections {
		let section = SectionBrief(name: entry.first?.text ?? "No Name")
		for sectionFood in Array(entry[1..<entry.count]).filter({ (element: HppleElement) -> Bool in return !element.isTextNode }) {
			var relevant = (sectionFood.children?.first)!
			
			// catches w/ issues
			let isSubFood = sectionFood.attributes["class"] as? String == "level3"
			if isSubFood {
				relevant = (sectionFood.children?[1])!
			}
			
			if let raw = relevant.raw {
				let foodName = relevant.text?.stringByReplacingOccurrencesOfString("&ntilde", withString: "ñ")
				let recipeRange = raw.rangeOfString("RecipeNumber=")
				// take the next six characters after the matched string
				let recipe = raw.substringWithRange(Range(start: (recipeRange?.endIndex)!, end: (recipeRange?.endIndex.successor().successor().successor().successor().successor().successor())!))
				let portionRange = raw.rangeOfString("PortionSize=")
				var portion = raw.substringWithRange(Range(start: (portionRange?.endIndex)!, end: (portionRange?.endIndex.successor().successor())!))
				let setToRemove = NSCharacterSet(charactersInString: "0123456789").invertedSet
				portion = portion.componentsSeparatedByCharactersInSet(setToRemove).joinWithSeparator("")
				
				var type:FoodType = .Regular
				if sectionFood.raw?.rangeOfString("VG.png") != nil { type = .Vegan }
				else if sectionFood.raw?.rangeOfString("V.png") != nil { type = .Vegetarian }
				
				if isSubFood { // false
					if let results = loadNutrition(recipe, portion: portion) {
						let withFood = FoodInfo(name: foodName ?? "[No Name]", recipe: recipe, type: type)
						withFood.nutrition = results.nutrition
						withFood.ingredients = results.ingredients
						(withFood.countryCode, withFood.description) = grabDetails(mealDescriptions[recipe])
						
						foods[recipe] = withFood
						let lastBrief = section.foods.removeLast()
						lastBrief.sideBrief = FoodBrief(food: withFood)
						section.foods.append(lastBrief)
					}
				} else {
					if let results = loadNutrition(recipe, portion: portion) {
						let food = FoodInfo(name: foodName ?? "[No Name]", recipe: recipe, type: type)
						food.nutrition = results.nutrition
						food.ingredients = results.ingredients
						(food.countryCode, food.description) = grabDetails(mealDescriptions[recipe])
						
						foods[recipe] = food
						section.foods.append(FoodBrief(food: food))
					}
				}
			}
		}
		restaurant.sections.append(section)
	}
	
	// sort it into display order!
	
	restaurant.sections.sortInPlace { (lhs, rhs) -> Bool in
		let lhsType = HallSectionType.typeFromString(lhs.name)
		let rhsType = HallSectionType.typeFromString(rhs.name)
		return lhsType > rhsType
	}
	
	return (true, restaurant, foods)
}

private func grabDetails(description: String?) -> (countryCode: String, description: String) {
	if let descr = description {
		if let range = descr.rangeOfString("<br/>") {
			return (descr.substringToIndex(range.startIndex), descr.substringFromIndex(range.endIndex))
		} else {
			return ("", descr)
		}
	}
	return ("", "")
}

// trying to make a helper to prevent repeating code between bcafe and dining halls
func processFoodPart(element: HppleElement, descriptions: Dictionary<String, String>) -> FoodInfo? {
	let raw = element.raw ?? ""
	let foodName = element.children?[0].text?.stringByReplacingOccurrencesOfString("&ntilde", withString: "ñ") ?? "No Name"
	
	let recipeRange = raw.rangeOfString("RecipeNumber=")
	// take the next six characters after the matched string (yes that's dumb)
	if let recipeRange = recipeRange {
		let recipe = raw.substringWithRange(Range(start: recipeRange.endIndex, end: recipeRange.endIndex.successor().successor().successor().successor().successor().successor()))
		
		let portionRange = raw.rangeOfString("PortionSize=")
		var portion = raw.substringWithRange(Range(start: (portionRange?.endIndex)!, end: (portionRange?.endIndex.successor().successor())!))
		let setToRemove = NSCharacterSet(charactersInString: "0123456789").invertedSet
		portion = portion.componentsSeparatedByCharactersInSet(setToRemove).joinWithSeparator("")
		
		var type:FoodType = raw.rangeOfString("VG.png") != nil ? .Vegan : .Regular
		if raw.rangeOfString("V.png") != nil { type = .Vegetarian }
		
		let food = FoodInfo(name: foodName, recipe: recipe, type: type)
		
		if let results = loadNutrition(recipe, portion: portion) {
			(food.nutrition, food.ingredients) = (results.nutrition, results.ingredients)
		} else {
			print("Load failed for \(food.name) with recipe \(food.recipe)")
		}
		
		(food.countryCode, food.description) = grabDetails(descriptions[recipe])
		
		return food
	} else {
		return nil
	}
}

func loadNutrition(recipe: String, portion: String) -> (nutrition: Dictionary<Nutrient, NutritionListing>, ingredients: String)? {
	let url = foodURL(recipe, portion: portion)
	
	for i in 0...3 { // attempt this load up to four times, since the connection can be bad.
		let html: String
		do {
			html = try NSString(contentsOfURL: NSURL(string: url)!, encoding: NSISOLatin1StringEncoding) as String
		} catch let error as NSError {
			print("Attempt \(i) failed: \(error)")
			continue
		}
		
		if html.rangeOfString("Nutrition") == nil { // fail case
			return (nutrition: [:], ingredients: "")
		}
		
		let parser = Hpple(HTMLData: html)
		return (nutrition: loadNutritionFacts(parser), ingredients: loadIngredients(parser))
	}
	return nil
}

// MARK: Helpers

/// Returns dictionary that maps from recipe numbers to descriptions.
/// Recipes without a description will not have a key in the dictionary
func foodDescriptions(html: String) -> Dictionary<String, String> {
	var javaRange = html.rangeOfString("<script language=\"javascript\">")
	var descriptionArea = html.substringFromIndex((javaRange?.endIndex)!)
	javaRange = descriptionArea.rangeOfString("</script>")
	descriptionArea = descriptionArea.substringToIndex((javaRange?.startIndex)!)
	descriptionArea = descriptionArea.stringByReplacingOccurrencesOfString("\t", withString: "")
	
	var recipeDescriptions: Dictionary<String, String> = Dictionary()
	for line in descriptionArea.componentsSeparatedByCharactersInSet(.newlineCharacterSet()) {
		if line.characters.count > 0 {
			var info = line.rangeOfString("recipeInfo[\"")
			var recipe = line.substringFromIndex((info?.endIndex)!)
			info = recipe.rangeOfString("\"] = ")
			var popover = recipe.substringFromIndex((info?.endIndex)!)
			popover = popover.stringByTrimmingCharactersInSet(NSCharacterSet(charactersInString: "\""))
			popover = popover.stringByTrimmingCharactersInSet(NSCharacterSet(charactersInString: "\";"))
			popover = popover.stringByReplacingOccurrencesOfString("\\\"", withString: "\"")
			popover = popover.stringByReplacingOccurrencesOfString("\\n", withString: "\n")
			recipe = recipe.substringToIndex((info?.startIndex)!)
			
			// parse popovers
			if let items = (Hpple(HTMLData: popover).searchWithXPathQuery("//*")) {
				for item in items {
					if let raw = item.children?.first?.children?.first?.raw, _ = raw.rangeOfString("<p>") {
						// clean up, add in
						var description = raw.stringByReplacingOccurrencesOfString("<p>", withString: "")
						description = description.stringByReplacingOccurrencesOfString("</p>", withString: "")
						description = description.stringByReplacingOccurrencesOfString("<br/>", withString: " ")
						description = description.stringByReplacingOccurrencesOfString("\n", withString: "")
						description = description.stringByReplacingOccurrencesOfString("&amp;ntilde", withString: "ñ")
						description = description.stringByReplacingOccurrencesOfString("&amp;", withString: "&")
						description = description.stringByTrimmingCharactersInSet(NSCharacterSet(charactersInString: "() "))
						if (description.characters.count > 1) { recipeDescriptions[recipe] = description }
					}
				}
			}
		}
	}
	
	return recipeDescriptions
}

func loadNutritionFacts(parser: Hpple) -> Dictionary<Nutrient, NutritionListing> {
	var nutrients: Dictionary<Nutrient, NutritionListing> = [:]
	var index = -1
	if let nodes = parser.searchWithXPathQuery("//div[@class='left_lightbox']")?.first?.children?[1].children {
		for node in nodes {
			index++
			if index > 6 && index < 28 && !node.isTextNode {
				// parse it out
				var cleanNode = (node.text)!.stringByTrimmingCharactersInSet(.whitespaceCharacterSet())
				if node.children?.count == 5 {
					switch index {
					case 13, 21: // Top level
						let first = (node.children?[1].text)!.stringByTrimmingCharactersInSet(.whitespaceCharacterSet())
						let second = (node.children?[3].text)!.stringByTrimmingCharactersInSet(.whitespaceCharacterSet())
						cleanNode = "\(first)\n\(second)"
					default: // Vitamins and Minerals (consider adding back .stringByTrimmingCharactersInSet(.whitespaceCharacterSet()))
						let oneA = (node.children?[1].children?[0].text)!
						let oneB = (node.children?[1].children?[2].text)!
						let twoA = (node.children?[3].children?[0].text)!
						let twoB = (node.children?[3].children?[2].text)!
						
						cleanNode = "\(oneA) \(oneB)\n\(twoA) \(twoB)"
					}
				}
				if node.children?.count == 3 {
					switch index {
					case 7:
						cleanNode = "\((node.children?[0].text)!) \(cleanNode)\n\((node.children?[2].text)!)"
					default:
						cleanNode = "\((node.children?[0].text)!) \(cleanNode)"
					}
				}
				if node.children?.count == 2 {
					cleanNode = "\((node.children?[0].text)!) \(cleanNode)"
				}
				
				for line in cleanNode.componentsSeparatedByCharactersInSet(.newlineCharacterSet()) {
					if line.characters.count > 0 {
						if let type = Nutrient.typeForName(line) {
							// remove name of entry from string
							let nutrIndex = (Nutrient.allValues.indexOf(type))!
							let displayName = Nutrient.allMatchingValues[nutrIndex]
							
							let displayNameRange = (line.rangeOfString(displayName))!
							var measure = line.substringFromIndex(displayNameRange.endIndex.successor()) // skip the inevitable space
							measure = measure.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
							
							// go either until the next space or the end of the string
							// check if there's one more space
							if let nextSpace = measure.rangeOfString(" ") {
								measure = measure.substringToIndex(nextSpace.startIndex)
							}
							
							// remove all non-numbers (and percent)
							measure = measure.stringByReplacingOccurrencesOfString(type.unit(), withString: "")
							nutrients[type] = NutritionListing(type: type, measure: measure)
						}
					}
				}
			}
		}
	}
	return nutrients
}

func loadIngredients(parser: Hpple) -> String {
	return parser.searchWithXPathQuery("//p[@class='rdingred_list']")?.first?.text ?? ""
}
