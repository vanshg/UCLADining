//
//  CloudManager.swift
//  BruinLoader
//
//  Created by Matthew DeCoste on 3/25/15.
//  Copyright (c) 2015 Matthew DeCoste. All rights reserved.
//

import UIKit
import Foundation
import CloudKit

import CoreData

private let _CloudManagerSharedInstance = CloudManager()
private let maxInAdvance = 13, minInAdvance = 6, addInAdvance = 3

private let HallRecordType = "DiningDay", QuickRecordType = "QuickMenu"
let HallEntityType = "DiningDay", QuickEntityType = "QuickMenu", FoodEntityType = "Food"
private let CKDateField = "Day", CKDataField = "Data", CDDateField = "day"
private let CKQuickRecordID = "quick"
private let mostRecentDownloadKey: String = "mostRecentDiningDownload"
private let quickKey: String = "quickDownloadDate"

class CloudManager: NSObject {
	private var container: CKContainer, publicDB: CKDatabase
	
	lazy var managedObjectContext: NSManagedObjectContext? = {
		return (UIApplication.sharedApplication().delegate as? AppDelegate)?.managedObjectContext
	}()
	
	class var sharedInstance: CloudManager {
		get {
			return _CloudManagerSharedInstance
		}
	}
	
	var upcomingDining: Array<DiningDay> {
		get {
			let request = NSFetchRequest(entityName: HallEntityType)
			request.predicate = NSPredicate(format: "day >= %@", comparisonDate())
			request.sortDescriptors = [NSSortDescriptor(key: CDDateField, ascending: true)]
			
			do {
				return try (managedObjectContext?.executeFetchRequest(request) as? Array<DiningDay>) ?? []
			} catch _ { // var error1 as NSError
				return []
			}
		}
	}
	
	private var firstGap: Int {
		get {
			if let lastDay = upcomingDining.last {
				return daysInFuture(lastDay.day) + 1
			}
			return 0
		}
	}
	
	private var quickDownloadDate: NSDate? {
		get {
			return getDownloadDate(quickKey)
		}
	}
	
	var quickData: NSData? {
		get {
			let fetchRequest = NSFetchRequest(entityName: QuickEntityType)
			do {
				return try (managedObjectContext?.executeFetchRequest(fetchRequest) as? Array<QuickMenu>)?.first?.data
			} catch _ {
				return nil
			}
		}
	}
	
	override init() {
		container = CKContainer(identifier: "iCloud.BruinLife.MatthewDeCoste")
		publicDB = container.publicCloudDatabase
	}
	
	func fetchNewRecords(type: String = "DiningDay", completion: (error: NSError!) -> Void) {
		fetchRecords(type, startDaysInAdvance: findFirstGap(), completion: completion)
	}
	
	func findFirstGap(daysInAdvance: Int = maxInAdvance) -> Int {
		let fetchRequest = NSFetchRequest(entityName: "DiningDay")
		fetchRequest.predicate = NSPredicate(format: "\(CDDateField) >= %@", comparisonDate())
		fetchRequest.sortDescriptors = [NSSortDescriptor(key: CDDateField, ascending: false)] // DateField
		
		do {
			if let firstFetchResult = try managedObjectContext?.executeFetchRequest(fetchRequest).first as? DiningDay {
				return daysInFuture(firstFetchResult.day)
			}
		} catch { }
		return 0
	}
	
	private func fetchRecords(type: String, startDaysInAdvance: Int = 0, completion: (error: NSError!) -> Void) {
		if startDaysInAdvance == maxInAdvance {
			completion(error: NSError(domain: "", code: 0, userInfo: nil))
			return // don't bother loading further
		}
		
		let startDate = comparisonDate(startDaysInAdvance), endDate = comparisonDate(min(maxInAdvance, max(startDaysInAdvance + addInAdvance, minInAdvance)))
		var results: Set<CKRecord> = []
		let operation = CKQueryOperation(query: CKQuery(recordType: type, predicate: NSPredicate(format: "(\(CKDateField) >= %@) AND (\(CKDateField) <= %@)", startDate, endDate)))
		operation.recordFetchedBlock = { (record) -> Void in
			results.insert(record)
			self.newDiningDay(record)
		}
		operation.queryCompletionBlock = { (cursor, error) in
			dispatch_async(dispatch_get_main_queue(), { () -> Void in
				self.save()
				let noResults = results.count == 0
				completion(error: noResults ? NSError(domain: "", code: 0, userInfo: nil) : error)
			})
		}
		publicDB.addOperation(operation)
	}
	
	// MARK:- Servings
	
	var eatenFoods: Set<Food> {
		get {
			let fetchRequest = NSFetchRequest(entityName: FoodEntityType)
			fetchRequest.predicate = NSPredicate(format: "servings > 0")
			
			var results: Set<Food> = []
			let allResults: Array<Food>
			
			do {
				try allResults = managedObjectContext?.executeFetchRequest(fetchRequest) as? Array<Food> ?? []
			} catch _ {
				allResults = []
			}
			
			for food in allResults {
//				food.resetForDate()
				if food.servings > 0 {
					results.insert(food)
				}
			}
			
			return results
		}
	}
	
	func eatenFood(recipe: String) -> Food? {
		var results: Array<Food>
		do {
			try results = self.managedObjectContext?.executeFetchRequest(NSFetchRequest(entityName: FoodEntityType)) as? Array<Food> ?? []
		} catch _ { // var error1 as NSError
			results = []
		}
		
		return results.filter({ $0.info.recipe == recipe }).first
	}
	
	func removeEaten(info: FoodInfo) {
		changeEaten(info, servings: 0)
	}
	
	/// Either modifies or adds
	func changeEaten(food: FoodInfo, servings: Int) {
		defaultFoodEntity(food)?.servings = Int16(servings)
		save()
	}
	
	func foodDetails(recipe: String) -> Food? {
		return eatenFood(recipe)
	}
	
	// MARK:- Update dates
	
	private func updateDownloadDate(dateKey: String, modDate: NSDate) {
		if modDate.timeIntervalSinceDate(getDownloadDate(mostRecentDownloadKey)) > 0 {
			_updateDownloadDateForKey(mostRecentDownloadKey, modDate: modDate)
		}
		_updateDownloadDateForKey(dateKey, modDate: modDate)
	}
	
	private func _updateDownloadDateForKey(dateKey: String, modDate: NSDate) {
		NSUserDefaults.standardUserDefaults().setObject(modDate, forKey: dateKey)
		NSUserDefaults.standardUserDefaults().synchronize()
	}
	
	private func getDownloadDate(dateKey: String) -> NSDate {
		return NSUserDefaults.standardUserDefaults().objectForKey(dateKey) as? NSDate ?? NSDate(timeIntervalSince1970: 0)
	}
	
	// MARK:- CloudKit
	
	func downloadNewRecords(type: String = HallRecordType, completion: (error: NSError!) -> Void) {
		let gap = firstGap
		
		downloadUpdatedRecords(endDaysInAdvance: gap, completion: completion)
		downloadRecords(type, startDaysInAdvance: gap, completion: completion)
		deleteOldRecords()
	}
	
	private func downloadUpdatedRecords(type: String = HallRecordType, endDaysInAdvance: Int = maxInAdvance, completion: (error: NSError!) -> Void) {
		if endDaysInAdvance != 0 {
			let operation = CKQueryOperation(query: CKQuery(recordType: HallRecordType, predicate: NSPredicate(format: "\(CKDateField) <= %@ AND \(CKDateField) >= %@", argumentArray: [comparisonDate(endDaysInAdvance), comparisonDate()])))
			operation.recordFetchedBlock = { (record: CKRecord!) -> Void in self.updateDiningDay(record) }
			operation.completionBlock = { completion(error: nil) }
			
			publicDB.addOperation(operation)
		}
	}
	
	private func downloadRecords(type: String, startDaysInAdvance: Int = 0, completion: (error: NSError!) -> Void) {
		if startDaysInAdvance < maxInAdvance {
			let operation = CKQueryOperation(query: CKQuery(recordType: HallRecordType, predicate: NSPredicate(format: "\(CKDateField) <= %@ AND \(CKDateField) >= %@", argumentArray: [comparisonDate(min(maxInAdvance, max(startDaysInAdvance + addInAdvance, minInAdvance))), comparisonDate(startDaysInAdvance)])))
			operation.recordFetchedBlock = { (record: CKRecord!) -> Void in self.newDiningDay(record) }
			
			operation.queryCompletionBlock = { (cursor: CKQueryCursor?, error: NSError?) -> Void in
				completion(error: error)
				if error != nil {
					self.save()
				}
			}
			
			publicDB.addOperation(operation)
		}
	}
	
	/// Delete records that are least four days old.
	private func deleteOldRecords() {
		let request = NSFetchRequest(entityName: HallEntityType)
		request.predicate = NSPredicate(format: "day <= %@", comparisonDate(-4))
		
		var results: Array<DiningDay>
		do {
			results = try managedObjectContext?.executeFetchRequest(request) as? Array<DiningDay> ?? []
		} catch _ {
			results = []
		}
		
		for result in results {
			managedObjectContext?.deleteObject(result)
		}
		save()
	}
	
	func downloadQuickRecord(completion: (error: NSError!) -> Void) {
		publicDB.fetchRecordWithID(CKRecordID(recordName: CKQuickRecordID)) { (record, error) -> Void in
			if let error = error {
				completion(error: error)
			} else {
				if let record = record {
					self.updateQuick(record)
				}
			}
		}
	}
	
	// MARK: - Core Data
	private func newDiningDay(record: CKRecord) {
		if let modDate = record.modificationDate {
			updateDownloadDate(record.recordID.recordName, modDate: modDate) // keeps update dates accurate
			
			if validDayData(record[CKDataField] as? NSData ?? NSData()) {
				diningDayEntity(record) // creates new record
			} else {
				print("STOPPED UNSAFE RECORD")
			}
		}
	}
	
	private func updateDiningDay(record: CKRecord) {
		if let modDate = record.modificationDate {
			updateDownloadDate(record.recordID.recordName, modDate: modDate)
		}
		
		if let date = record[CKDateField] as? NSDate, data = record[CKDataField] as? NSData, day = diningDay(date) where day.data != data && validDayData(data) {
			day.data = data
			NSNotificationCenter.defaultCenter().postNotificationName("DiningDayUpdated", object: nil, userInfo:["updatedData":data])
//			handleDayUpdate(day.data)
			save()
		}
	}
	
	private func diningDayEntity(record: CKRecord) {
		if let moc = managedObjectContext, date = record[CKDateField] as? NSDate, data = record[CKDataField] as? NSData {
			let compDate = comparisonDate(date)
			if let day = diningDay(compDate) {
				if day.data != data {
					day.data = data
					NSNotificationCenter.defaultCenter().postNotificationName("DayInfoUpdated", object: nil, userInfo:["updatedItem":day])
//					handleDayUpdate(day.data)
				}
			}
			
			if let newEntity = NSEntityDescription.insertNewObjectForEntityForName(HallEntityType, inManagedObjectContext: moc) as? DiningDay {
				newEntity.data = data
				newEntity.day = compDate
//				addRecurringNotifications(DayBrief(dict: deserialized(data)))
				NSNotificationCenter.defaultCenter().postNotificationName("NewDayInfoAdded", object: nil, userInfo:["newItem":newEntity])
				
				save()
			}
		} else {
			print("\(record.recordID.recordName) is not a valid dining day record")
		}
	}
	
	private func defaultFoodEntity(food: FoodInfo) -> Food? {
		if let eaten = eatenFood(food.recipe) {
			return eaten
		} else {
			if let moc = managedObjectContext, newFood = NSEntityDescription.insertNewObjectForEntityForName("Food", inManagedObjectContext: moc) as? Food {
				newFood.data = serialize(food)
				newFood.favorite = false
				newFood.notify = false
				newFood.date = comparisonDate()
				newFood.servings = 0
				return newFood
			}
		}
		return nil
	}
	
	private func quickEntity(record: CKRecord) {
		if let data = record[CKDataField] as? NSData {
			if let quick = quickMenu {
				if quick.data != data {
					_updateQuick(quick, newData: data)
				} // else = same data as always (should be primary case)
			} else { // creating quick data for first time!
				_makeFirstQuick(data)
				
			}
		}
	}
	
	private func _makeFirstQuick(data: NSData) {
		if let moc = managedObjectContext, quick = NSEntityDescription.insertNewObjectForEntityForName("QuickMenu", inManagedObjectContext: moc) as? QuickMenu {
			_updateQuick(quick, newData: data)
		}
	}
	
	private func _updateQuick(quick: QuickMenu, newData: NSData) {
		quick.data = newData
		NSNotificationCenter.defaultCenter().postNotificationName("QuickInfoUpdated", object: nil, userInfo: ["quickInfo" : quick])
	}
	
	func diningDay(date: NSDate) -> DiningDay? {
		let request = NSFetchRequest(entityName: HallEntityType)
		request.predicate = NSPredicate(format: "\(CDDateField) == %@", comparisonDate(date))
		
		do {
			return try (managedObjectContext?.executeFetchRequest(request) as? Array<DiningDay>)?.first
		} catch _ { // var error1 as NSError
			return nil
		}
	}
	
	var quickMenu: QuickMenu? {
		get {
			do {
				return try (managedObjectContext?.executeFetchRequest(NSFetchRequest(entityName: QuickEntityType)) as? Array<QuickMenu>)?.first
			} catch _ { }
			return nil
		}
	}
	
	/// Returns whether day data is safe
	private func validDayData(data: NSData) -> Bool {
		if let dict = deserializedOpt(data), _ = dict["date"] as? String, _ = dict["meals"] as? Dictionary<String, Dictionary<String, AnyObject>>, _ = dict["foods"] as? Dictionary<String, Dictionary<String, AnyObject>> {
			return true
		}
		return false
	}
	
	private func updateQuick(record: CKRecord) {
		if let modificationDate = record.modificationDate {
			updateDownloadDate(quickKey, modDate: modificationDate)
			quickEntity(record)
		}
	}
	
	func save() {
		do {
			try managedObjectContext?.save()
		} catch _ { }
	}
	
	// MARK: - Upload
	
	private func idFromDate(date: NSDate) -> CKRecordID {
		let form = NSDateFormatter()
		form.dateStyle = .ShortStyle
		return CKRecordID(recordName: form.stringFromDate(date))
	}
	
	func addRecord(date: NSDate, data: NSData, completion: (record: CKRecord) -> Void, halted: () -> Void) {
		if let dict = deserializedOpt(data) where DayBrief.isValid(dict) {
			// download the current record (if it exists) and compare
			publicDB.fetchRecordWithID(idFromDate(date), completionHandler: { (fetched, error) -> Void in
				let hasError: Bool
				if let err = error {
					hasError = true
					print(err) // TODO: check for the error type
				} else {
					hasError = false
				}
				if let recData = fetched?[CKDataField] as? NSData where recData != data {
					self.addDayRecord(date, data: data, completion: completion)
				} else if !hasError { // Nothing has changed for this date
					halted()
				} else {
					// It's new!
					self.addDayRecord(date, data: data, completion: completion)
				}
			})
		}
	}
	
	func addDayRecord(date: NSDate, data: NSData, completion: (record: CKRecord) -> Void) {
		let record = CKRecord(recordType: HallRecordType, recordID: idFromDate(date))
		record[CKDateField] = comparisonDate(date)
		record[CKDataField] = data
		
		let saveOp = CKModifyRecordsOperation(recordsToSave: [record], recordIDsToDelete: [])
		saveOp.savePolicy = .ChangedKeys
		saveOp.modifyRecordsCompletionBlock = { savedRecords, deletedRecordIDs, error in
			if let hasError = error {
				print("Error!: \(hasError.description)")
			}
			if let firstSaved = savedRecords?.first {
				completion(record: firstSaved)
			}
		}
		publicDB.addOperation(saveOp)
	}
	
	func addQuickRecord(data: NSData, completion: (record: CKRecord) -> Void) {
		let record = CKRecord(recordType: QuickRecordType, recordID: CKRecordID(recordName: "quick"))
		record[CKDataField] = data
		
		let saveOp = CKModifyRecordsOperation(recordsToSave: [record], recordIDsToDelete: [])
		saveOp.savePolicy = CKRecordSavePolicy.ChangedKeys
		saveOp.modifyRecordsCompletionBlock = { savedRecords, deletedRecordIDs, error in
			if let hasError = error {
				print("Error!: \(hasError.description)")
			}
			if let firstSaved = savedRecords?.first {
				completion(record: firstSaved)
			}
		}
		publicDB.addOperation(saveOp)
	}
}
