//
//  Helpers.swift
//  BruinLoader
//
//  Created by Matthew DeCoste on 6/11/15.
//  Copyright (c) 2015 Matthew DeCoste. All rights reserved.
//

import Foundation

let numberDaysToLoadKey: String = "QuickActionNumberOfDaysToLoad"

enum LoaderQuickActionType: String {
	case LoadDiningDays
	
	var type: String {
		get {
			switch self {
			case .LoadDiningDays:
				return "LoadDiningDays"
			}
		}
	}
	
	var title: String {
		get {
			switch self {
			case .LoadDiningDays:
				return "Load Hall Menus"
			}
		}
	}
	
	func subtitle(dayCount: Int) -> String {
		return "Load \(dayCount) days"
	}
}

protocol Serializable {
	func dictFromObject() -> Dictionary<String, AnyObject>
	init(dict: Dictionary<String, AnyObject>)
}

enum Progress: String {
	case Waiting = "StartedWaiting", Loading = "StartedLoading"
	case Error = "EncounteredError", Loaded = "FinishedLoading"
	case Uploaded = "FinishedUpload", NoChange = "NoChange"
}

func realDateFromOptional(date: NSDate?) -> NSDate {
	return date ?? NSDate(timeIntervalSince1970: 0)
}

func postProgressNotification(date: NSDate?, progress: Progress) {
	NSNotificationCenter.defaultCenter().postNotificationName("ProgressChanged", object: realDateFromOptional(date), userInfo: ["progress" : progress.rawValue])
}

func postProgressNotification(date: NSDate?, meal: MealType) {
	NSNotificationCenter.defaultCenter().postNotificationName("LoadingMealChanged", object: realDateFromOptional(date), userInfo: ["meal" : meal.rawValue])
}

func postProgressNotification(date: NSDate?, hall: Halls) {
	NSNotificationCenter.defaultCenter().postNotificationName("LoadingHallChanged", object: realDateFromOptional(date), userInfo: ["hall" : hall.rawValue])
}

func postProgressNotification(date: NSDate?, data: NSData) {
	NSNotificationCenter.defaultCenter().postNotificationName("DataLengthChanged", object: realDateFromOptional(date), userInfo: ["data" : data])
}

func errorOccuredInLoad(date: NSDate?, error: NSError) {
	postProgressNotification(date, progress: .Error)
}

func deserialized(data: NSData) -> Dictionary<String, AnyObject> {
	return deserializedOpt(data) ?? [:]
}

func deserializedOpt(data: NSData) -> Dictionary<String, AnyObject>? {
	do {
		return try NSJSONSerialization.JSONObjectWithData(data, options: []) as? Dictionary<String, AnyObject>
	} catch {
		return nil
	}
}

func serialize(object: Serializable) -> NSData {
	do {
		return try NSJSONSerialization.dataWithJSONObject(object.dictFromObject(), options: [])
	} catch {
		return NSData()
	}
}

func representsToday(date: NSDate) -> Bool {
	return daysInFuture(date) == 0
}

func daysInFuture(date: NSDate) -> Int {
	return NSCalendar.currentCalendar().components(.Day, fromDate: comparisonDate(), toDate: comparisonDate(date), options: []).day
}

class Time {
	var hour: Int
	var minute: Int
	
	// provides the "closed time" version of Time
	init() {
		hour = 0
		minute = 0
	}
	
	/// give hour in 24 hour notation (can be more than 24 hours if past midnight)
	init(hour: Int, minute: Int) {
		self.hour = hour
		self.minute = minute
	}
	
	init(hoursString: String) {
		let formatter = NSDateFormatter()
		formatter.dateFormat = "h:mma"
		let comps = NSCalendar.currentCalendar().components([.Hour, .Minute], fromDate: formatter.dateFromString(hoursString)!)
		let increase = (comps.hour < 7) ? 24 : 0
		self.hour = comps.hour + increase
		self.minute = comps.minute
	}
	
	init(hoursString: String, date: NSDate) {
		let formatter = NSDateFormatter()
		formatter.dateFormat = "h:mma"
		let interval = formatter.dateFromString(hoursString)!.timeIntervalSinceDate(date)
		
		self.hour = Int(interval) / 3600
		self.minute = Int(interval % 3600) / 60
	}
	
	func timeDateForDate(dayDate: NSDate?) -> NSDate? {
		let interval = 3600.0 * Double(hour) + 60 * Double(minute)
		return NSCalendar.currentCalendar().dateBySettingHour(0, minute: 0, second: 0, ofDate: dayDate!, options: NSCalendarOptions())?.dateByAddingTimeInterval(interval)
	}
	
	func displayString() -> String {
		let formatter = NSDateFormatter()
		formatter.dateFormat = "h:mm a"
		return formatter.stringFromDate(timeDateForDate(NSDate())!)
	}
}

func unwrappedTime(time: Time?) -> Time {
	return time ?? Time()
}