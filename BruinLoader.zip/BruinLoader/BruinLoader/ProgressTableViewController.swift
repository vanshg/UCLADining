//
//  ProgressTableViewController.swift
//  BruinLoader
//
//  Created by Matthew DeCoste on 8/24/15.
//  Copyright © 2015 Matthew DeCoste. All rights reserved.
//

import UIKit

class ProgressTableViewController: UITableViewController {
	let progressID = "Progress", quickProgressID = "QuickProgress"
	
	var isLoading = false {
		didSet {
			navigationItem.title = isLoading ? "Loading" : "Done"
		}
	}
	var numLoading = 8
	private var numLoaded: Int {
		get {
			return responses.filter({ $0.progress == .Uploaded || $0.progress == .NoChange }).count
		}
	}
	var responses: Array<(date: NSDate, progress: Progress, meal: MealType, hall: Halls, data: NSData?)> = []
	var quickResponses: Array<(hall: Halls, progress: Progress)> = []
	var shouldLoadDiningMenus = true
	var shouldLoadQuickMenu = false
	
    override func viewDidLoad() {
        super.viewDidLoad()
		
		tableView.registerClass(ProgressTableViewCell.self, forCellReuseIdentifier: progressID)
		
		navigationItem.title = "Loading"
		
		NSNotificationCenter.defaultCenter().addObserver(self, selector: "dayStarted:", name: "LoadStarted", object: nil)
		NSNotificationCenter.defaultCenter().addObserver(self, selector: "dayFinished:", name: "ProgressChanged", object: nil)
		NSNotificationCenter.defaultCenter().addObserver(self, selector: "loadingMealChanged:", name: "LoadingMealChanged", object: nil)
		NSNotificationCenter.defaultCenter().addObserver(self, selector: "loadingHallChanged:", name: "LoadingHallChanged", object: nil)
		NSNotificationCenter.defaultCenter().addObserver(self, selector: "dataLengthChanged:", name: "DataLengthChanged", object: nil)
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
		return shouldLoadQuickMenu ? 2 : 1
    }

	override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		switch section {
		case 0:
			return numLoading
		case 1:
			return 1
		default:
			return 0
		}
	}

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
		switch indexPath.section {
		case 0:
			return progressCell(indexPath.row)
		default:
			return progressCell(indexPath.row)
		}
    }
	
	func progressCell(row: Int) -> UITableViewCell {
		let cell = tableView.dequeueReusableCellWithIdentifier(progressID, forIndexPath: NSIndexPath(forRow: row, inSection: 0)) as? ProgressTableViewCell ?? ProgressTableViewCell()
		cell.date = comparisonDate(row)
		if responses.count > row {
			cell.progress = responses[row].progress
			cell.dataLength = responses[row].data?.length ?? 0
		} else {
			cell.progress = .Waiting
			cell.dataLength = 0
		}
		
		return cell
	}
	
	func quickProgressCell(row: Int) -> UITableViewCell {
		let cell = tableView.dequeueReusableCellWithIdentifier(quickProgressID) as? QuickProgressTableViewCell ?? QuickProgressTableViewCell()
		if responses.count > row {
			cell.progress = responses[row].progress
		}
		
		return cell
	}
	
	func load(details: LoadDetails) {
		numLoading = details.numDays
		shouldLoadDiningMenus = (numLoading != 0)
		shouldLoadQuickMenu = details.loadQuick
		
		load()
	}
	
	func load() {
		isLoading = true
		
		responses = (0..<numLoading).map({ (date: comparisonDate($0), progress: Progress.Waiting, meal: .Breakfast, hall: .DeNeve, data: nil) })
		if shouldLoadQuickMenu {
			responses.append((date: NSDate(timeIntervalSince1970: 0), progress: Progress.Waiting, meal: .Breakfast, hall: .BruinCafe, data: nil))
		}
		
		if shouldLoadDiningMenus || shouldLoadQuickMenu {
			tableView.reloadData()
		}
		
		if shouldLoadDiningMenus && numLoading > 0 {
			dispatch_async(backgroundQueue, { () -> Void in
				preload(self.numLoading - 1)
			})
		}
		
		if shouldLoadQuickMenu {
			dispatch_async(backgroundQueue, { () -> Void in
				loadAndSaveQuick()
			})
		}
	}
	
	func dayStarted(notification: NSNotification) {
		if let date = notification.object as? NSDate {
			let days = correctedIndexFromDate(date)
			responses[days].progress = .Waiting
			numLoading = responses.count
			
			dispatch_async(dispatch_get_main_queue(), { () -> Void in
				self.tableView.reloadData()
			})
		}
	}
	
	func dayFinished(notification: NSNotification) {
		if let date = notification.object as? NSDate, progStr = notification.userInfo?["progress"] as? String, prog = Progress(rawValue: progStr) {
			let days = correctedIndexFromDate(date)
			if days < responses.count {
				responses[days].progress = prog
				isLoading = numLoaded != numLoading
				
				if let progCell = self.tableView.cellForRowAtIndexPath(NSIndexPath(forRow: days, inSection: 0)) as? ProgressTableViewCell {
					dispatch_async(dispatch_get_main_queue(), { () -> Void in
						progCell.date = date
						progCell.progress = self.responses[days].progress
					})
				}
			}
		}
	}
	
	func loadingMealChanged(notification: NSNotification) {
		if let date = notification.object as? NSDate, mealStr = notification.userInfo?["meal"] as? String, meal = MealType(rawValue: mealStr) {
			let days = correctedIndexFromDate(date)
			if days < responses.count {
				responses[days].meal = meal
				
				if let progCell = self.tableView.cellForRowAtIndexPath(NSIndexPath(forRow: days, inSection: 0)) as? ProgressTableViewCell {
					dispatch_async(dispatch_get_main_queue(), { () -> Void in
						progCell.date = date
						progCell.meal = self.responses[days].meal
					})
				}
			}
		}
	}
	
	func loadingHallChanged(notification: NSNotification) {
		if let date = notification.object as? NSDate, hallStr = notification.userInfo?["hall"] as? String, hall = Halls(rawValue: hallStr) {
			let days = correctedIndexFromDate(date)
			if days < responses.count {
				responses[days].hall = hall
				
				if let progCell = self.tableView.cellForRowAtIndexPath(NSIndexPath(forRow: days, inSection: 0)) as? ProgressTableViewCell {
					dispatch_async(dispatch_get_main_queue(), { () -> Void in
						progCell.date = date
						progCell.hall = self.responses[days].hall
					})
				}
			}
		}
	}
	
	func dataLengthChanged(notification: NSNotification) {
		if let date = notification.object as? NSDate, data = notification.userInfo?["data"] as? NSData {
			let days = correctedIndexFromDate(date)
			if responses.indices ~= days {
				responses[days].data = data
				if let progCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: days, inSection: 0)) as? ProgressTableViewCell {
					dispatch_async(dispatch_get_main_queue(), { () -> Void in
						progCell.date = date
						progCell.dataLength = data.length
					})
				}
			}
		}
	}
	
	override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
		tableView.deselectRowAtIndexPath(indexPath, animated: true)
	}
	
	private func correctedIndexFromDate(date: NSDate) -> Int {
		var days = daysInFuture(date)
		if days < 0 {
			days = responses.count - 1
		}
		return days
	}
}

class ProgressTableViewCell: UITableViewCell {
	var date: NSDate = NSDate() {
		didSet {
			let form = NSDateFormatter()
			form.dateStyle = .MediumStyle
			textLabel?.text = form.stringFromDate(date)
		}
	}
	
	var dataLength: Int = 0 {
		didSet {
			if dataLength > oldValue || dataLength == 0 {
				updateDetailLabel()
			}
		}
	}
	
	var progress: Progress = .Waiting {
		didSet {
			updateDetailLabel()
		}
	}
	
	var meal: MealType = .Breakfast {
		didSet {
			updateDetailLabel()
		}
	}
	
	var hall: Halls = .DeNeve {
		didSet {
			updateDetailLabel()
		}
	}
	
	override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
		super.init(style: .Value1, reuseIdentifier: reuseIdentifier)
	}
	
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
	}
	
	private func updateDetailLabel() {
		var progressString = labelForProgress(progress, meal: meal)
		if let sublabel = sublabelForProgress(progress, hall: hall) {
			progressString += " \(sublabel)"
		}
		if dataLength > 0 {
			progressString += " – \(NSByteCountFormatter().stringFromByteCount(Int64(dataLength)))"
		}
		detailTextLabel?.text = progressString
	}
}

class QuickProgressTableViewCell: UITableViewCell {
	var hall: Halls = Halls.BruinCafe {
		didSet {
			textLabel?.text = hall.displayName(false)
		}
	}
	
	var progress: Progress = .Waiting {
		didSet {
			detailTextLabel?.text = progress.rawValue
		}
	}
	
	override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
		super.init(style: .Value1, reuseIdentifier: reuseIdentifier)
	}
	
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
	}
}

private func labelForProgress(progress: Progress, meal: MealType) -> String {
	let baseLabel: String
	switch progress {
	case .Waiting:
		baseLabel = ""
	case .Loading:
		baseLabel = meal.rawValue
	case .Error:
		baseLabel = "Error!"
	case .Loaded:
		baseLabel = "Parsed"
	case .Uploaded:
		baseLabel = "Changed!"
	case .NoChange:
		baseLabel = "Same"
	}
	return baseLabel
}

private func sublabelForProgress(progress: Progress, hall: Halls) -> String? {
	switch progress {
	case .Loading:
		return hall.displayName(true)
	default:
		return nil
	}
}

func canReplace(new: Progress, previous: Progress) -> Bool {
	switch new {
	case .Waiting:
		return false
	case .Uploaded, .NoChange, .Error:
		return true
	case .Loaded:
		return previous == .Waiting || previous == .Loading
	case .Loading:
		return previous == .Waiting
	}
}
